﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Alarm_Clock
//{
//    class TimeEvent
//    {
//        public int _hour { get; set; }
//        public int _minute { get; set; }

//        public void timeEvent (object sender, EventArgs e)
//        {
//            Hour
//        }
//    }
//}
