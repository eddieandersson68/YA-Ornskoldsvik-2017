﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alarm_Clock
{
    public class Hour
    {
        private int hourValue = 0;
        
        public void SetHour(int hour)
        {
            hourValue = hour;
        }
        public int GetHour()
        {
            return hourValue;
        }

        public bool Tick()
        {
            if( hourValue == 23)
            {
                hourValue = 0;
                return true;
            }
            else
            {
                hourValue += 1;
                return false;
            }
        }
    }
}
