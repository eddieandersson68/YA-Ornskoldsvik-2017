﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace Alarm_Clock
{
    public class Clock
    {
        Timer timer;
        Hour hour = new Hour();
        Minute minute = new Minute();
        //public event EventHandler<TimeEvent> Timechanged;
        
        public Clock()
        {
            timer = new Timer();
            timer.Interval = 1000;
            timer.Elapsed += Timer_Elapsed;
            //Timechanged.Invoke("");
       
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            minute.Tick();
            hour.Tick();
            //Timechanged.Invoke(new TimeEvent(hour,minute));
        }

        public void SetTime()
        {
           
        }
        public void GetHours()
        {
            hour.Tick();
        }
        public void GetMinutes()
        {
            minute.Tick();
            if(minute.GetMinute()<=59)
            {
                
            }
        }
        public void StartClock()
        {
            timer.Start();
        }
        public void StopClock()
        {
            timer.Stop();
            //StopClock stopClock = new StopClock();
            //stopClock.Start();
            //for (int i = 0;  i < 1000; i++)
            //{
            //    System.Threading.Thread.Sleep(10);
            //}
            //stopClock.Stop();
        }
    }
}
