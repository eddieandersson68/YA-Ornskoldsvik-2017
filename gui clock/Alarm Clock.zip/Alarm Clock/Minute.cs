﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alarm_Clock
{
    public class Minute
    {
        private int minuteValue = 0;

        public void SetMinute(int minute)
        {
            minuteValue = minute;
        }
        public int GetMinute()
        {
            return minuteValue;
        }

        public bool Tick()
        {
          
            if (minuteValue == 59)
            {
                minuteValue = 0;
                return true;
            }       
            else
            {
                minuteValue += 1;
                return false;
            }
          
            
        }

    }
}
