﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsBank
{
    public partial class Form1 : Form
    {
        decimal DepositAmount1;
        decimal DepositAmount2;
        decimal transfer1;
        decimal transfer2;

        Account a1 = new Account();
        Account a2 = new Account();

        public Form1()
        {
            InitializeComponent();
            DisplayBalance();
        }
        
        public void DisplayBalance()
        {
            tBxAccount2Balance.Text = Convert.ToString("Balance of a2: " + (a2.Balance));
            tBxAccount1Balance.Text = Convert.ToString("Balance of a1: " + (a1.Balance));
        }

        private void txBxDeposit1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DepositAmount1 = decimal.Parse(txBxDeposit1.Text);
                a1.Depostit(DepositAmount1);
                DisplayBalance();
            }

        }

        private void txBxDeposit2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DepositAmount2 = decimal.Parse(txBxDeposit2.Text);
                a2.Depostit(DepositAmount2);
                DisplayBalance();

            }

        }


        private void txBxTrans1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                transfer1 = Convert.ToDecimal(txBxTrans1.Text);
                a1.TransferFunds1(a2, a1, transfer1);
                DisplayBalance();
            }
            else if (transfer1 > a1.Balance)
            {
                MessageBox.Show("Account a1 does not have sufficient funds for that transaction." +
                                $"Available funds in the account are {a1.Balance}");
            }
        }


        private void txBxTrans2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                transfer2 = Convert.ToDecimal(txBxTrans2.Text);
                a2.TransferFunds2(a1, a2, transfer2);
                DisplayBalance();
            }
        }

        private void txBxDeposit1_KeyPress(object sender, KeyPressEventArgs e)
        {
            a1.TransferFunds1(a1, a2, DepositAmount1);

            tBxAccount1Balance.Text = Convert.ToString(a1.Balance);
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != '.')

            {
                e.Handled = true;
            }
            //if (!char.IsNumber(e.KeyChar))

            //{

            //    e.Handled = true;

            //}


            //e.Handled = (char.IsLetter(e.KeyChar)
            //             || e.KeyChar == (char) Keys.Space
            //             || e.KeyChar == (char) Keys.Back
            //   
        }

    }
}

