﻿namespace FormsBank
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tBxAccount1Balance = new System.Windows.Forms.TextBox();
            this.tBxAccount2Balance = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txBxTrans2 = new System.Windows.Forms.TextBox();
            this.txBxTrans1 = new System.Windows.Forms.TextBox();
            this.dep = new System.Windows.Forms.Label();
            this.txBxDeposit1 = new System.Windows.Forms.TextBox();
            this.txBxDeposit2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Accoun 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Account 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(318, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Balance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(318, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Balance";
            // 
            // tBxAccount1Balance
            // 
            this.tBxAccount1Balance.Location = new System.Drawing.Point(321, 41);
            this.tBxAccount1Balance.Name = "tBxAccount1Balance";
            this.tBxAccount1Balance.Size = new System.Drawing.Size(100, 20);
            this.tBxAccount1Balance.TabIndex = 6;
            // 
            // tBxAccount2Balance
            // 
            this.tBxAccount2Balance.Location = new System.Drawing.Point(321, 96);
            this.tBxAccount2Balance.Name = "tBxAccount2Balance";
            this.tBxAccount2Balance.Size = new System.Drawing.Size(100, 20);
            this.tBxAccount2Balance.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(186, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Transfer";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(186, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Transfer";
            // 
            // txBxTrans2
            // 
            this.txBxTrans2.Location = new System.Drawing.Point(176, 96);
            this.txBxTrans2.Name = "txBxTrans2";
            this.txBxTrans2.Size = new System.Drawing.Size(100, 20);
            this.txBxTrans2.TabIndex = 10;
            this.txBxTrans2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txBxTrans2_KeyDown);
            // 
            // txBxTrans1
            // 
            this.txBxTrans1.Location = new System.Drawing.Point(176, 41);
            this.txBxTrans1.Name = "txBxTrans1";
            this.txBxTrans1.Size = new System.Drawing.Size(100, 20);
            this.txBxTrans1.TabIndex = 11;
            this.txBxTrans1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txBxTrans1_KeyDown);
            // 
            // dep
            // 
            this.dep.AutoSize = true;
            this.dep.Location = new System.Drawing.Point(28, 25);
            this.dep.Name = "dep";
            this.dep.Size = new System.Drawing.Size(43, 13);
            this.dep.TabIndex = 12;
            this.dep.Text = "Deposit";
            // 
            // txBxDeposit1
            // 
            this.txBxDeposit1.Location = new System.Drawing.Point(31, 41);
            this.txBxDeposit1.Name = "txBxDeposit1";
            this.txBxDeposit1.Size = new System.Drawing.Size(100, 20);
            this.txBxDeposit1.TabIndex = 13;
            this.txBxDeposit1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txBxDeposit1_KeyDown);
            // 
            // txBxDeposit2
            // 
            this.txBxDeposit2.Location = new System.Drawing.Point(31, 96);
            this.txBxDeposit2.Name = "txBxDeposit2";
            this.txBxDeposit2.Size = new System.Drawing.Size(100, 20);
            this.txBxDeposit2.TabIndex = 14;
            this.txBxDeposit2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txBxDeposit2_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Deposit";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 222);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txBxDeposit2);
            this.Controls.Add(this.txBxDeposit1);
            this.Controls.Add(this.dep);
            this.Controls.Add(this.txBxTrans1);
            this.Controls.Add(this.txBxTrans2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tBxAccount2Balance);
            this.Controls.Add(this.tBxAccount1Balance);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tBxAccount1Balance;
        private System.Windows.Forms.TextBox tBxAccount2Balance;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txBxTrans2;
        private System.Windows.Forms.TextBox txBxTrans1;
        private System.Windows.Forms.Label dep;
        private System.Windows.Forms.TextBox txBxDeposit1;
        private System.Windows.Forms.TextBox txBxDeposit2;
        private System.Windows.Forms.Label label7;
    }
}

