﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exersice4.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Point currentPoint = new Point();
        Line newLine;
        Point start;
        Point end;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void Rect_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            var clickedElement = e.OriginalSource;
            MessageBox.Show("Rectangel Clicked");
        }


        public void Circle_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            var clickedElement = e.OriginalSource;
            MessageBox.Show("Circle Clicked");
        }

        public void BtnCircle_OnClick(object sender, RoutedEventArgs e)
        {
            var myCircle = new Ellipse()
            {
                Stroke = Brushes.Black,
                Fill = Brushes.Red,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,

                Height = 50,
                Width = 50
            };
            myCircle.MouseDown += Circle_PreviewMouseDown;
            InkCanvas.SetTop(myCircle, 50);
            InkCanvas.SetLeft(myCircle, 155);
            InkCanvas.Children.Add(myCircle);
        }

        public void BtnRect_OnClick(object sender, RoutedEventArgs e)
        {
            var myRectangle = new Rectangle
            {
                Stroke = Brushes.Black,
                Fill = Brushes.SkyBlue,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center,
                Height = 50,
                Width = 70
            };

            myRectangle.MouseDown += Rect_PreviewMouseDown;
            InkCanvas.SetTop(myRectangle, 50);
            InkCanvas.SetLeft(myRectangle, 50);
            InkCanvas.Children.Add(myRectangle);


        }

        public void BtnClear_OnClick(object sender, RoutedEventArgs e)
        {
            InkCanvas.Children.Clear();
        }

        private void BtnSelect_OnClick(object sender, RoutedEventArgs e)
        {
            InkCanvas.EditingMode = InkCanvasEditingMode.Select;
        }

        private void BtnDraw_OnClick(object sender, RoutedEventArgs e)
        {
            InkCanvas.EditingMode = InkCanvasEditingMode.InkAndGesture;

        }

        private void BtnErase_OnClick(object sender, RoutedEventArgs e)
        {
            InkCanvas.Strokes.Clear();
        }

        private void rectRed_up(object sender, RoutedEventArgs e)
        {
            InkCanvas.DefaultDrawingAttributes.Color = Colors.Red;
        }

        private void rectGreen_up(object sender, RoutedEventArgs e)
        {
            InkCanvas.DefaultDrawingAttributes.Color = Colors.Green;
        }

        private void rectBlue_up(object sender, RoutedEventArgs e)
        {
            InkCanvas.DefaultDrawingAttributes.Color = Colors.Blue;
        }




        private void InkCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
                currentPoint = e.GetPosition(this);
        }


        private void InkCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Line line = new Line();

                line.Stroke = SystemColors.WindowFrameBrush;
                line.X1 = currentPoint.X;
                line.Y1 = currentPoint.Y;
                line.X2 = e.GetPosition(this).X;
                line.Y2 = e.GetPosition(this).Y;

                currentPoint = e.GetPosition(this);

                InkCanvas.Children.Add(line);
            }
        }


        private void DrawCanvas_MouseUp_1(object sender, MouseButtonEventArgs e)
        {

            newLine = new Line();
            newLine.Stroke = SystemColors.WindowFrameBrush;
            newLine.X1 = start.X;
            newLine.Y1 = start.Y;
            newLine.X2 = end.X;
            newLine.Y2 = end.Y;

            InkCanvas.Children.Add(newLine);
        }
    }
}
