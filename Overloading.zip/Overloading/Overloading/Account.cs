﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Diagnostics.SymbolStore;
using System.Threading;

namespace Overloading
{

    public class Account
    {
       
        // public Guid ID;
        public decimal Amount { get; set; }
        public string Name { get; set; }
        public int count { get; set; }  

        public void TransferFunds(Account a1, Account a2, decimal trans)
        {
            a1.Withdraw(trans);
            a2.Depostit(trans);

            trans += a2.Amount; 
        }

        public void  Depostit (decimal dep)
        {
            Amount += dep;
        }

        public void Withdraw (decimal witdrw)
        {
            Amount -= witdrw;
        }

    }
}
