﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overloading
{
    class Program
    {
        

        static void Main(string[] args)
        {
            Account b1 = new Account();
            Account b2 = new Account();

            b1.Depostit (10000);
            Console.WriteLine(b1.Amount.ToString());
            b1.Withdraw(5000);
            Console.WriteLine(b1.Amount.ToString());
            Console.ReadLine();




            Console.ReadLine();
        }
    }
}
