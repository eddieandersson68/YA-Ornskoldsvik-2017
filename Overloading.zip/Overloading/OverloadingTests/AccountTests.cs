﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Overloading;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overloading.Tests
{
    [TestClass()]
    public class AccountTests
    {
        [TestMethod()]
        public void TransferFundsTest()
        {
            Account a1 = new Account();
            Account a2 = new Account();
            
            a1.Depostit(500);
            a2.Depostit(300);
            
            if (a1.Amount < 200)
                Assert.Fail();
        }
        
        [TestMethod()]
        public void Depostit100Test()
        {
            Account a1 = new Account();
            a1.Depostit(100);
            if(a1.Amount != 100)
                Assert.Fail();
        }

        [TestMethod()]
        public void WithdrawTest()
        {
            Account a1 = new Account();
            a1.Depostit(100);
            a1.Withdraw(50);
            if (a1.Amount != 50)
                Assert.Fail();
        }
    }
}